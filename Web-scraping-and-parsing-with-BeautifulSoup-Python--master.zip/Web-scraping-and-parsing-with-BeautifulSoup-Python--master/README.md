# Web-scraping-and-parsing-with-BeautifulSoup-Python-
The need and importance of extracting data from the web is becoming increasingly loud and clear. Every few weeks, I find myself in a situation where we need to extract data from the web.
